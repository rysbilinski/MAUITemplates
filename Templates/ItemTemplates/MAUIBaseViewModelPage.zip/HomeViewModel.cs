﻿namespace $defaultnamespace$.ViewModels;

public class $fileinputname$ViewModel : BaseViewModel
{
    public $fileinputname$ViewModel()
	{
        
    }
}
