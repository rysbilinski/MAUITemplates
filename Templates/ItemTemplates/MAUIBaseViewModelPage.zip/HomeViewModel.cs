﻿namespace $rootnamespace$.ViewModels;

public class $fileinputname$ViewModel : BaseViewModel
{
    public $fileinputname$Model()
	{
        
    }
}
