namespace $rootnamespace$;

public partial class $safeitemname$ : BaseViewModelPage
{
	public $safeitemname$($fileinputname$ViewModel vm)
	{
		InitializeComponent();

		this.BindingContext = vm;
	}
}