namespace $rootnamespace$;

public partial class $safeitemname$ : BaseViewModelPage
{
	public $safeitemname$(HomeViewModel vm)
	{
		InitializeComponent();

		this.BindingContext = vm;
	}
}