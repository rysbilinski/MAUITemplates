﻿global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.Text;
global using System.Threading.Tasks;
global using CommunityToolkit.Mvvm.ComponentModel;
global using $safeprojectname$.ViewModels;
global using CommunityToolkit.Maui;
global using $safeprojectname$.Services;


