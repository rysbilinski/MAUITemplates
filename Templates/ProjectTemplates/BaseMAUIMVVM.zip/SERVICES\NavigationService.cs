﻿namespace $safeprojectname$.Services;

public interface INavigationService
{

}
public class NavigationService : INavigationService
{
}
